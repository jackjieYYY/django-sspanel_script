default_app_config = "apps.sspanel.apps.SspanelConfig"
